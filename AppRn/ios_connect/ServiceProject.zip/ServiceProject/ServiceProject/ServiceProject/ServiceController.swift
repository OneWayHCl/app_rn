//
//  ServiceController.swift
//  ServiceProject
//
//  Created by hcl on 2022/4/4.
//

import Foundation
import UIKit

class ServiceController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    var viewModel:ServiceViewModel = ServiceViewModel.init()
    
    override func viewDidLoad() {
        self.title = "服务"
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2 + viewModel.imageArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return ServiceCell.cellHeight(tabModelArry: viewModel.tabModelArry)
        } else if indexPath.row == 1 {
            return 54
        } else {
            return 120
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 0 {
            let cell:ServiceCell = tableView.dequeueReusableCell(withIdentifier: "ServiceCell") as! ServiceCell
            cell.updateWithDataSource(tabModelArry: viewModel.tabModelArry)
            cell.selectedValueChange = {
                self.tableView.reloadData()
            }
            return cell
            
        } else if indexPath.row == 1 {
            let cell:ServiceCenterCell = tableView.dequeueReusableCell(withIdentifier: "ServiceCenterCell") as! ServiceCenterCell
            cell.detailLabel.text = viewModel.centerInfo
            return cell
            
        } else {
            let cell:ServiceImageCell = tableView.dequeueReusableCell(withIdentifier: "ServiceImageCell") as! ServiceImageCell
            cell.detaiImageView?.image = UIImage.init(named: viewModel.imageArray[indexPath.row - 2])
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row > 1 {
            let data = viewModel.imageArray[indexPath.row - 2]
            print("tableView_didSelectRowAt:\(data)")
        }
    }
}
