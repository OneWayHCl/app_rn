//
//  LoginController.swift
//  ServiceProject
//
//  Created by hcl on 2022/4/5.
//

import Foundation
import UIKit

class LoginController: UIViewController {
    
    override func viewDidLoad() {
        
    }
    
    
}
