//
//  ServiceViewModel.swift
//  ServiceProject
//
//  Created by hcl on 2022/4/4.
//

import Foundation

class ServiceViewModel {
    
    var tabModelArry:[ServiceTabModel] = []
    
    var centerInfo:String = "服务资讯"
    
    var imageArray:[String] = []
    
    init() {
        self.imageArray = ["image_1", "image_2", "image_3"]
        
        for i in 0..<5 {
            let tab:ServiceTabModel = ServiceTabModel.init(index: i)
            tabModelArry.append(tab)
        }
    }
}

class ServiceTabModel {
    
    var tabTitle:String = ""
    
    var selected:Bool = false
    
    var detailArray:[ServiceTabDetailModel] = []

    init(index: NSInteger) {
        tabTitle = "OPPO_\(index)"
        selected = index == 0
        
        let conut = 4 + arc4random() % 8
        for i in 0..<conut {
            let detail:ServiceTabDetailModel = ServiceTabDetailModel.init(index: NSInteger(i), superIndex: index)
            detailArray.append(detail)
        }
    }
}

class ServiceTabDetailModel {
    
    var title:String?
    
    var imageName:String?
    
    init(index: NSInteger, superIndex:NSInteger) {
        title = "\(superIndex)保障服务\(index)"
        imageName = "icon_\(NSInteger(1 + arc4random() % 7))"
    }
}
