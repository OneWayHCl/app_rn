//
//  ServiceCell.swift
//  ServiceProject
//
//  Created by hcl on 2022/4/4.
//

import Foundation
import UIKit

class ServiceCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var tabCollectionView: UICollectionView!
    
    @IBOutlet weak var detailCollectionView: UICollectionView!
    
    var tabModelArry:[ServiceTabModel]?
    
    var selectedValueChange: (()->())?
    
    override func awakeFromNib() {
        
        self.selectionStyle = .none
        
        let layout = UICollectionViewFlowLayout.init()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.estimatedItemSize = CGSize.init(width: 10, height: 40)
        layout.scrollDirection = .horizontal
        tabCollectionView.contentInset = UIEdgeInsets.init(top: 0, left: 20, bottom: 0, right: 20)
        tabCollectionView.collectionViewLayout = layout
        tabCollectionView.showsHorizontalScrollIndicator = false
        
        let layout1 = UICollectionViewFlowLayout.init()
        layout1.minimumLineSpacing = 0
        layout1.minimumInteritemSpacing = 0
        layout1.itemSize = CGSize.init(width: (UIScreen.main.bounds.width - 40) / 4, height: 77)
        detailCollectionView.contentInset = UIEdgeInsets.init(top: 8, left: 20, bottom: 0, right: 20)
        detailCollectionView.collectionViewLayout = layout1
        detailCollectionView.showsVerticalScrollIndicator = false
        detailCollectionView.isScrollEnabled = false
    }
    
    func selectedTabModel() -> ServiceTabModel {
        if let array = tabModelArry {
            for item in array {
                if item.selected {
                    return item
                }
            }
        }
        return ServiceTabModel.init(index: 0)
    }
    
    class func cellHeight(tabModelArry:[ServiceTabModel]) -> CGFloat {
        
        var selectTab = ServiceTabModel.init(index: 0)
        for item in tabModelArry {
            if item.selected {
                selectTab = item
                break
            }
        }
        let count = selectTab.detailArray.count
        var line = NSInteger(count / 4)
        if count % 4 > 0 {
            line += 1
        }
        return 40.0 + 8.0 + CGFloat(line) * 77.0
    }
    
    func updateWithDataSource(tabModelArry:[ServiceTabModel]) {
        self.tabModelArry = tabModelArry
        self.tabCollectionView.reloadData()
        self.detailCollectionView.reloadData()
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == tabCollectionView {
            return self.tabModelArry?.count ?? 0
        } else {
            let selectTab = self.selectedTabModel()
            return selectTab.detailArray.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == tabCollectionView {
            let cell:ServiceCollectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ServiceCollectionCell", for: indexPath) as! ServiceCollectionCell
            cell.tabModel = tabModelArry?[indexPath.item]
            return cell
            
        } else {
            let cell:ServiceCollectionDetailCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ServiceCollectionDetailCell", for: indexPath) as! ServiceCollectionDetailCell
            let selectTab = self.selectedTabModel()
            cell.detailModel = selectTab.detailArray[indexPath.item]
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == tabCollectionView {
            if let array = tabModelArry {
                for item in array {
                    item.selected = false
                }
            }
            let tabModel = tabModelArry?[indexPath.item]
            tabModel?.selected = true
            if self.selectedValueChange != nil {
                self.selectedValueChange!()
            }
        } else {
            let selectTab = self.selectedTabModel()
            let detailModel = selectTab.detailArray[indexPath.item]
            print(detailModel.title ?? "")
        }
    }
}

class ServiceCenterCell: UITableViewCell {
    
    @IBOutlet weak var detailLabel: UILabel!
    
    override func awakeFromNib() {
        self.selectionStyle = .none
    }
}

class ServiceImageCell: UITableViewCell {
    
    @IBOutlet weak var detaiImageView: UIImageView!
    
    override func awakeFromNib() {
        self.selectionStyle = .none
        self.detaiImageView.layer.cornerRadius = 8
        self.detaiImageView.layer.masksToBounds = true
        
//        //使用URL设置图像
//        let url = URL(string: "https://example.com/image.jpg")
//        imageView.kf.setImage(with: url)
//        
//        //背景图设置
//        let image = UIImage(named: "default_profile_icon")
//        imageView.kf.setImage(with: url, placeholder: image)
//
//        //下载loading
//        imageView.kf.indicatorType = .activity
//        imageView.kf.setImage(with: url)
//
//        //过渡动画
//        imageView.kf.setImage(with: url, options: [.transition(.fade(0.2))])
//
//        //下载完成处理
//        imageView.kf.setImage(with: url) { result in
//            // `result` is either a `.success(RetrieveImageResult)` or a `.failure(KingfisherError)`
//            switch result {
//            case .success(let value):
//                // The image was set to image view:
//                print(value.image)
//
//                // From where the image was retrieved:
//                // - .none - Just downloaded.
//                // - .memory - Got from memory cache.
//                // - .disk - Got from disk cache.
//                print(value.cacheType)
//
//                // The source object which contains information like `url`.
//                print(value.source)
//
//            case .failure(let error):
//                print(error) // The error happens
//            }
//        }
//
//        //圆角图片
//        let processor = RoundCornerImageProcessor(cornerRadius: 20)
//        imageView.kf.setImage(with: url, options: [.processor(processor)])
//
//        //缓存Cache
//        let resource = ImageResource(downloadURL: url, cacheKey: "cache_Key")
//        imageView.kf.setImage(with: resource)
//
//        //查看缓存
//        let cache = ImageCache.default
//        let cached = cache.isCached(forKey: cacheKey)
//
//        // To know where the cached image is:
//        let cacheType = cache.imageCachedType(forKey: cacheKey)
//        // `.memory`, `.disk` or `.none`.
    }
}


class ServiceCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var tabLabel: UILabel!
    
    @IBOutlet weak var lineView: UIView!
    
    var tabModel:ServiceTabModel? {
        didSet {
            tabLabel.text = tabModel?.tabTitle
            lineView.isHidden = !(tabModel?.selected ?? false)
        }
    }
    
    override func awakeFromNib() {
        
    }
}

class ServiceCollectionDetailCell: UICollectionViewCell {
    
    @IBOutlet weak var iconView: UIImageView!
    
    @IBOutlet weak var detailLabel: UILabel!
    
    var detailModel:ServiceTabDetailModel? {
        didSet {
            iconView.image = UIImage.init(named: detailModel?.imageName ?? "")
            detailLabel.text = detailModel?.title
        }
    }
    
    override func awakeFromNib() {
        
    }
}
